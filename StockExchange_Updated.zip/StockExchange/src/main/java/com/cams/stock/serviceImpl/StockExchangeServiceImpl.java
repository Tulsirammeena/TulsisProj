package com.cams.stock.serviceImpl;

import org.springframework.stereotype.Service;

import com.cams.stock.service.StockExchangeService;

@Service
public class StockExchangeServiceImpl implements StockExchangeService {


}
